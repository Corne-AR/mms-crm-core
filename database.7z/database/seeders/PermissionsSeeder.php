<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PermissionsSeeder extends Seeder
{
    public function run(): void
    {
        $permissions = [
            'view_quotes',
            'create_quotes',
            'edit_quotes',
            'delete_quotes',
            'convert_quotes_to_invoices',

            'view_invoices',
            'create_invoices',
            'edit_invoices',
            'delete_invoices',

            'view_customers',
            'create_customers',
            'edit_customers',
            'delete_customers',

            'view_products',
            'create_products',
            'edit_products',
            'delete_products',

            'view_kits',
            'create_kits',
            'edit_kits',
            'delete_kits',

            'manage_terms',
            'manage_settings',
            'manage_users',
            'view_activity_logs',
            'view_email_logs',
        ];

        foreach ($permissions as $permission) {
            DB::table('permissions')->insert([
                'name' => $permission,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}