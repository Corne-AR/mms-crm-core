<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;

class UsersSeeder extends Seeder
{
    public function run(): void
    {
        // Admin user
        DB::table('users')->updateOrInsert(
            ['email' => 'admin@example.com'],
            [
                'name' => 'Admin User',
                'password' => Hash::make('password'),
                'role' => 'admin', // USE STRING HERE
                'updated_at' => Carbon::now(),
                'created_at' => Carbon::now(),
            ]
        );

        // Key Dealer user
        DB::table('users')->updateOrInsert(
            ['email' => 'keydealer@example.com'],
            [
                'name' => 'Key Dealer User',
                'password' => Hash::make('password'),
                'role' => 'key_dealer', // USE STRING HERE
                'updated_at' => Carbon::now(),
                'created_at' => Carbon::now(),
            ]
        );

        // Sub Dealer user
        DB::table('users')->updateOrInsert(
            ['email' => 'subdealer@example.com'],
            [
                'name' => 'Sub Dealer User',
                'password' => Hash::make('password'),
                'role' => 'sub_dealer', // USE STRING HERE
                'updated_at' => Carbon::now(),
                'created_at' => Carbon::now(),
            ]
        );
    }
}
