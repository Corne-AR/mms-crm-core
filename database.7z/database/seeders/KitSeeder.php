<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class KitSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('kits')->insert([

            [
                'kit_code' => '8 006 010 047',
                'kit_name' => 'NX510 SE Package (International)',
                'unit' => 'Kit',
                'price' => 87750.00,
                'currency' => 'ZAR',
                'category' => 'Agriculture',
                'type' => 'Autosteer',
                'special_notes' => 'Include UHF Radio Rx - can use NTRIP, Add iBaseAG',
                'kit_contents' => '
                    <ul>
                        <li>PA-3UB-FAYWY Receiver</li>
                        <li>GASensor Angle Sensor Kit</li>
                        <li>CB-H10 Tablet Console</li>
                        <li>CES-T5.1 Motor Steering Wheel</li>
                        <li>FA3A220 Camera</li>
                        <li>AgNav3.0 Software (Android)</li>
                        <li>Radio Antenna (magnetic mount)</li>
                        <li>GASensor Angle Sensor Cable 3.0</li>
                        <li>Integrated Main Cable V510-A</li>
                        <li>Camera Cable</li>
                        <li>2x PA-3 Mounting Bracket Kit</li>
                        <li>Steering Wheel Mount (Standard)</li>
                        <li>T Mount Kit (A)</li>
                        <li>T Mount Kit (B)</li>
                        <li>Ball Holder</li>
                        <li>Double Socket Arm</li>
                        <li>Sleeve for Motor Mounting</li>
                    </ul>
                ',
                'created_at' => now(),
                'updated_at' => now(),
            ],

            [
                'kit_code' => '8 006 010 162',
                'kit_name' => 'NX612 Package (International)',
                'unit' => 'Kit',
                'price' => 97500.00,
                'currency' => 'ZAR',
                'category' => 'Agriculture',
                'type' => 'Autosteer',
                'special_notes' => 'L-Band (SkyTrix) - 12 month included',
                'kit_contents' => '
                    <ul>
                        <li>NX612 Package (International)</li>
                        <li>PA-5AH-GXY00 Receiver</li>
                        <li>2x A-1 Mounting Bracket Kit</li>
                        <li>CB-H12 Tablet Console</li>
                        <li>CES-T6 Motor Steering Wheel</li>
                        <li>Steering Knob</li>
                        <li>MC011B Camera</li>
                        <li>Integrated Main Cable</li>
                        <li>Steering Wheel Mount (Standard)</li>
                        <li>T Mount Kit (A)</li>
                        <li>T Mount Kit (B)</li>
                        <li>Ball Holder</li>
                        <li>Double Socket Arm</li>
                        <li>QCA0050 Magnetic Base for Radio Antenna (50cm)</li>
                        <li>QCA0051 Radio Antenna</li>
                        <li>1 Year SkyTrix Subscription</li>
                    </ul>
                ',
                'created_at' => now(),
                'updated_at' => now(),
            ],

            [
                'kit_code' => '8 001 010 338',
                'kit_name' => 'iBase Ag Base Station',
                'unit' => 'Kit',
                'price' => 48067.50,
                'currency' => 'ZAR',
                'category' => 'Agriculture',
                'type' => 'Base',
                'special_notes' => 'only uses CHC protocol, not for RTK, excludes Tripod',
                'kit_contents' => '
                    <ul>
                        <li>iBase GNSS Receiver</li>
                        <li>Pole Mounting</li>
                        <li>External Power Cable</li>
                        <li>Extension Pole (30cm)</li>
                        <li>Transport Hard Case</li>
                    </ul>
                ',
                'created_at' => now(),
                'updated_at' => now(),
            ],

        ]);
    }
}