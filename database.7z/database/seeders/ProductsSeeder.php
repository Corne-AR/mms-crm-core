<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Product;

class ProductsSeeder extends Seeder
{
    public function run(): void
    {
        $products = [
            [
                'part_number' => '8 000 900 108',
                'description' => 'NX510 SE GNSS Receiver with UHF Radio (Rx / Tx)',
                'price' => 33200.00,
                'currency' => 'ZAR',
                'vat_applicable' => true,
                'discount_applicable' => true,
                'bulk_discount_applicable' => true,
                'shipping_fee_applicable' => true,
                'list_contents' => '<ul><li>PA-3UB-FAYWY GNSS Receiver</li><li>Mounting Kit</li><li>User Manual</li></ul>',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'part_number' => '8 000 900 109',
                'description' => 'GASensor Angle Sensor Kit',
                'price' => 8300.00,
                'currency' => 'ZAR',
                'vat_applicable' => true,
                'discount_applicable' => false,
                'bulk_discount_applicable' => false,
                'shipping_fee_applicable' => true,
                'list_contents' => '<ul><li>GASensor Module</li><li>Cable</li><li>Mounting Accessories</li></ul>',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'part_number' => '8 000 900 129',
                'description' => 'CB-H10 Tablet Console',
                'price' => 14800.00,
                'currency' => 'ZAR',
                'vat_applicable' => true,
                'discount_applicable' => true,
                'bulk_discount_applicable' => false,
                'shipping_fee_applicable' => true,
                'list_contents' => '<ul><li>CB-H10 Tablet</li><li>Mounting Kit</li><li>Charger</li></ul>',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'part_number' => '8 001 000 308',
                'description' => 'CES-T5.1 Motor Steering Wheel',
                'price' => 27500.00,
                'currency' => 'ZAR',
                'vat_applicable' => true,
                'discount_applicable' => true,
                'bulk_discount_applicable' => true,
                'shipping_fee_applicable' => true,
                'list_contents' => '<ul><li>Motor</li><li>Steering Wheel Mount</li><li>Controller Cable</li></ul>',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'part_number' => '8 001 000 025',
                'description' => 'FA3A220 Camera',
                'price' => 3500.00,
                'currency' => 'ZAR',
                'vat_applicable' => true,
                'discount_applicable' => false,
                'bulk_discount_applicable' => false,
                'shipping_fee_applicable' => true,
                'list_contents' => '<ul><li>FA3A220 Camera</li><li>Power Cable</li><li>Bracket</li></ul>',
                'created_at' => now(),
                'updated_at' => now(),
            ],
                   // ADD MORE PRODUCTS HERE using your Excel!
        ];

        foreach ($products as $product) {
            Product::create($product);
        }
    }
}