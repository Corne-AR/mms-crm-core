<?php

// QuoteController.php
namespace App\Http\Controllers;

use App\Models\Quote;
use App\Models\QuoteItem;
use App\Models\Invoice;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class QuoteController extends Controller
{
    public function index() {
        return Quote::with('items')->orderBy('created_at', 'desc')->get();
    }

    public function show($id) {
        return Quote::with('items')->findOrFail($id);
    }

    public function store(Request $request) {
        $validated = $request->validate([
            'subdealer_id' => 'required|exists:users,id',
            'customer_id' => 'required|exists:customers,id',
            'user_id' => 'required|exists:users,id',
            'quote_date' => 'required|date',
            'terms' => 'nullable|array',
            'currency' => 'required|string|max:10',
        ]);

        $nextNumber = Quote::max('id') + 1;
        $quoteNumber = 'Q-' . str_pad((string)$nextNumber, 5, '0', STR_PAD_LEFT);

        $quote = Quote::create([
            'quote_number' => $quoteNumber,
            'subdealer_id' => $validated['subdealer_id'],
            'customer_id' => $validated['customer_id'],
            'user_id' => $validated['user_id'],
            'quote_date' => $validated['quote_date'],
            'status' => 'Draft',
            'terms' => $validated['terms'] ?? [],
            'subtotal' => 0,
            'vat_amount' => 0,
            'total_amount' => 0,
            'currency' => $validated['currency'],
            'is_pdf_generated' => false,
        ]);

        return response()->json($quote, 201);
    }

    public function edit($id) {
        $quote = Quote::with('items')->findOrFail($id);
        return response()->json($quote);
    }

    public function update(Request $request, $id) {
        $quote = Quote::with('items')->findOrFail($id);

        $data = $request->all();
        $quote->update($data);

        $quote->total_amount = (float) $quote->subtotal + (float) $quote->vat_amount;
        $quote->save();

        return response()->json($quote);
    }

    public function convertToInvoice($id) {
        $quote = Quote::with('items')->findOrFail($id);

        DB::transaction(function () use ($quote) {
            $invoice = Invoice::create([
                'invoice_number' => 'INV-' . str_pad((string)(Invoice::max('id') + 1), 5, '0', STR_PAD_LEFT),
                'customer_id' => $quote->customer_id,
                'user_id' => $quote->user_id,
                'quote_id' => $quote->id,
                'invoice_date' => now(),
                'status' => 'Pending',
                'terms' => $quote->terms,
                'subtotal' => $quote->subtotal,
                'vat_amount' => $quote->vat_amount,
                'total_amount' => $quote->total_amount,
                'currency' => $quote->currency,
                'converted_from_quote_at' => now(),
                'is_pdf_generated' => false,
            ]);

            $quote->update([
                'status' => 'Invoiced',
                'converted_to_invoice_at' => now(),
            ]);
        });

        return response()->json(['message' => 'Quote converted to Invoice!']);
    }
}